package com.oliviabecht.stockwatchobechtapp;

/*
Adapter
We have something called a ViewHolder, this holds the View for each row that
will show in the recycler view

The adapter keeps track of all rows (all ViewHolders)
Each row in the recycler view will represent some Object (in our case that is a Note Object)

 */

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder>  {

    //You need a list to hold all of the data that you want to show
    private ArrayList<Stock> allStocks;
    private Context context;
    //private TextView notesTitleTextView;

    //Constructor, this runs first when you make a new adapter. pass in everything you will need in this class
    //which must at least be the data and most of the time you'll need the context
    public Adapter(ArrayList<Stock> data, Context context){
        allStocks = data;
        this.context = context;
        //this.notesTitleTextView = notesTitleTextView;
    }


    @NonNull
    @Override
    //This creates the view so inflate the correct xml file for one item in the rec view
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //this method creates what will be shown in this recycler view and defines all action for button clicks
        final View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.rec_view_stock, parent, false);
        //call the view holder class to assign xml to java elements
        final ViewHolder view_holder = new ViewHolder(v);
        return view_holder;
    }

    private void updateThemeForNegatives(ViewHolder holder) {
        holder.txtChange.setTextColor(Color.RED);
        holder.txtName.setTextColor(Color.RED);
        holder.txtPercentChange.setTextColor(Color.RED);
        holder.txtTradePrice.setTextColor(Color.RED);
        holder.txtCompany.setTextColor(Color.RED);

        //change triangle image to negative resouce with red color
        holder.triangle.setColorFilter(Color.RED);
        holder.triangle.setRotation(180);
    }

    @Override
    //this actually puts the data where it is supposed to go
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        //position represents the 0 indexed row that we are on right now in the recycler view
        Stock stock = allStocks.get(position);
        //this method puts the data from the list in this class into the correct spot in our layout
        //Put the data in the text views
        String name = stock.getSymbol();
        //String dateStringForNote = allStocks.get(position).getDate()

        holder.txtName.setText(name);
        //the age is an int so we have to convert it to a string to put it in the textview
        //holder.txtDate.setText( dateStringForNote );
        holder.txtCompany.setText(stock.getCompany());
        /*
        TODO figure out rounding numbers like -.000001
        so that they don't show up like -0.00
         */

        holder.txtTradePrice.setText(stock.getPriceChange().toString());
        String priceChangeFormat = String.format("%.2f", stock.getPriceChange());
        holder.txtChange.setText(priceChangeFormat);
        String percentChangeFormatted = String.format("%.2f", stock.getPercentChange());
        holder.txtPercentChange.setText("(" + percentChangeFormatted + "%)");

        if(Double.compare(Double.parseDouble(percentChangeFormatted), (double) 0) < 0) {
            updateThemeForNegatives(holder);
            Log.i("NEG: " + stock.getSymbol(), stock.getPercentChange().toString());
        }

        //if you click on the whole row and hold it
        holder.row.setOnLongClickListener(view -> {

            Dialog dialog = new Dialog(view.getContext());
            dialog.setContentView(R.layout.delete_stock);
            TextView deleteMessage = dialog.findViewById(R.id.deleteMessage);
            deleteMessage.setText("Delete Stock Symbol " + name + "?");
            //dialog.setCanceledOnTouchOutside(true);
            Button cancel = dialog.findViewById(R.id.buttonCancel);
            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog.dismiss();
                }
            });
            Button delete = dialog.findViewById(R.id.buttonDelete);
            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    allStocks.removeIf(currentStock -> currentStock.getSymbol().equals(name));
                    saveRestOfNotes(view.getContext());
                    notifyItemRemoved(position);
                    dialog.dismiss();
                }
            });
            dialog.show();

            return false;
        });

        //this would be the extra credit section where goes to website
        //Normal tap
        holder.row.setOnClickListener(view -> {
            String url = "https://www.marketwatch.com/investing/stock/" + stock.getSymbol();
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            //this.context.startActivity(i, Activity.FLAG_ACTIVITY_NEW_TASK);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            i.putExtra("note",allStocks.get(position));
            i.putExtra("existingStocks", allStocks);
            i.putExtra("positionOfStock", position);

            this.context.startActivity(i);
        });


    }


    //this is for the swipe refresh
    //maybe fix the array list part if doesnt input correctly
    /* Within the RecyclerView.Adapter class */
/*
    // Clean all elements of the recycler
    public static void clear() {
        allStocks.clear();
        notifyDataSetChanged();
    }

    // Add a list of items -- change to type used
    public static void addAll(ArrayList<Stock> stocks) {
        allStocks.addAll(stocks);
        notifyDataSetChanged();
    }
*/

    /**
     * After deleting note, rewrite notes.json
     */
    private void saveRestOfNotes(Context context){
        try {
            File file = new File(context.getFilesDir(), MainActivity.FILENAME);
            //check to see if this file exists
            String filesDir = context.getFilesDir().getAbsolutePath();
            if (!file.exists()){
                file.createNewFile();
            }
            FileOutputStream fos = context.openFileOutput(MainActivity.FILENAME, Context.MODE_PRIVATE);

            JSONArray stocksJSONArray = new JSONArray();

            for(int i = 0; i < allStocks.size(); i++) {
                JSONObject newStockObj = new JSONObject();
                newStockObj.put("name", allStocks.get(i).getSymbol());
                newStockObj.put("company", allStocks.get(i).getCompany());
                //newStockObj.put("date", allStocks.get(i).getDate());
                stocksJSONArray.put(newStockObj);
            }
            fos.write(stocksJSONArray.toString().getBytes());
            fos.close();
        } catch (Exception e) {
            Log.d("Write ERROR", "Error: could not write to note file");
            e.printStackTrace();
        }
        Log.d("Write Success", "good");
    }

    public Stock getItem(int i){
        return allStocks.get(i);
    }

    @Override
    //*****REALLY IMPORTANT******
    //If this returns 0 it wont show any data. This returns how many row items should be shown
    //so it should always match the size of the data to show
    public int getItemCount() {
        return allStocks.size();
    }

    //view holder class helps keep the previously created views in memory so they load faster
    //this should be all the xml elements in your layout and it should map them to their java variables
    public static class ViewHolder extends RecyclerView.ViewHolder{
        //This should represent all XML elements in one row of the recycler view
        TextView txtName,txtCompany, txtTradePrice, txtChange, txtPercentChange;
        ConstraintLayout row;
        ImageView triangle;
        public ViewHolder(@NonNull View view) {
            super(view);
            txtName = view.findViewById(R.id.recName);
            txtCompany = view.findViewById(R.id.recCompany);
            txtTradePrice = view.findViewById(R.id.recTradePrice);
            //txtPriceChange = view.findViewById(R.id.recPriceChange);
            triangle = view.findViewById(R.id.recTriangle);
            txtChange = view.findViewById(R.id.recDecChange);
            txtPercentChange = view.findViewById(R.id.recPercChange);

            row = view.findViewById(R.id.cnsStockRow);
        }
    }

    public void sortAndShow () {
        allStocks.sort(new Comparator<Stock>() {
            @Override
            public int compare(Stock stock1, Stock stock2) {
                return stock1.getSymbol().compareTo(stock2.getSymbol());
            }
        });

        notifyDataSetChanged();
    }

}
