package com.oliviabecht.stockwatchobechtapp;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class StockDownloader {


    public static void getStock(Context context, String symbol, ArrayList<Stock> stocks, Object... optionalParams) {

        String url = "https://cloud.iexapis.com/stable/stock/" + symbol + "/quote?token=pk_440b0e642c714f65b7586858ccbcb0c7";

        JsonObjectRequest request = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response){
                        String symbol = "unset";
                        try {
                            symbol = response.getString("symbol");
                            String companyName = response.getString("companyName");
                            double latestPrice = 0.00;
                            if (!response.isNull("latestPrice")) {
                                latestPrice = response.getDouble("latestPrice");
                            }
                            double priceChange = 0.00;
                            if (!response.isNull("change")) {
                                priceChange = response.getDouble("change");
                            }
                            double changePercent = 0.00;
                            if (!response.isNull("changePercent")) {
                                changePercent = response.getDouble("changePercent");
                            }
                            Stock newStock = new Stock(symbol, companyName, latestPrice, priceChange, changePercent);
                            stocks.add(newStock);


                            if(optionalParams.length == 2) {
                                Dialog dialog = (Dialog) optionalParams[0];
                                Adapter adapter  = (Adapter) optionalParams[1];

                                adapter.notifyDataSetChanged();
                                dialog.dismiss();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("JSON", "Symbol: " + symbol);
                            Log.d("JSON", e.toString());
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println(error.toString());
                    }
                });

        Log.d("STOCK", "Requesting: " + symbol);
        VolleySingleton.getInstance(context).addToRequestQueue(request);

    }




}
