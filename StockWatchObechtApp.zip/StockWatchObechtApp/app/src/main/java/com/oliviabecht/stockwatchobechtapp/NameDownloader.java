package com.oliviabecht.stockwatchobechtapp;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class NameDownloader {

    public interface NameDownloaderMethods {
        void onNamesLoaded ();
    }
    public static HashMap<String, String> symbolToCompanyName= new HashMap<>();

    public static void getStockNames(Context context, NameDownloaderMethods methods) {

        final String url = "https://cloud.iexapis.com/stable/ref-data/symbols?token=pk_440b0e642c714f65b7586858ccbcb0c7";

        JsonArrayRequest request = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response){
                        for(int i = 0; i < response.length(); i++) {
                            try {
                                JSONObject currentStock = response.getJSONObject(i);
                                symbolToCompanyName.put(currentStock.getString("symbol"), currentStock.getString("name"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                        methods.onNamesLoaded();
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println(error.toString());
                    }
                });

        VolleySingleton.getInstance(context).addToRequestQueue(request);

    }

}
