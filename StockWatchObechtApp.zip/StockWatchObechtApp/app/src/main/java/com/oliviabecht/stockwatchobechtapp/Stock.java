package com.oliviabecht.stockwatchobechtapp;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class Stock implements Serializable {

    private final String TAG = "Stock";

    private static final String STOCK_NAME = "name";
    private static final String STOCK_COMPANY = "company";
    private static final String STOCK_PRICE = "price";
    private static final String STOCK_PRICE_CHANGE = "priceChange";
    private static final String STOCK_PERCENT_CHANGE = "percentChange";

    private String symbol;
    private String company;
    private double price;
    private double priceChange;
    private double percentChange;

    public Stock(String symbol, String company, double price, double priceChange, double percentChange) {
        this.symbol = symbol;
        this.company = company;
        this.price = price;
        this.priceChange = priceChange;
        this.percentChange = percentChange;
    }

    public String getSymbol() {
        return symbol;
    }
    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getCompany() {
        return company;
    }
    public void setCompany(String company) {
        this.company = company;
    }

    public Double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }

    public Double getPriceChange() {
        return priceChange;
    }
    public void setPriceChange(double priceChange) {this.priceChange = priceChange;}

    public Double getPercentChange() {return percentChange;}
    public void setPercentChange(double percentChange) {
        this.percentChange = percentChange;
    }


    public JSONObject toJSON(){
        JSONObject out = new JSONObject();
        try {
            out.put(STOCK_NAME, symbol);
            out.put(STOCK_COMPANY, company);
            out.put(STOCK_PRICE, price);
            out.put(STOCK_PRICE_CHANGE, priceChange);
            out.put(STOCK_PERCENT_CHANGE, percentChange);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return out;
    }

    //add a constructor that can take in a json object
    public Stock(JSONObject in){
        try {
            symbol = in.getString(STOCK_NAME);
            Log.d("Stock", "name:" + symbol);
            company = in.getString(STOCK_COMPANY);
            price = Double.parseDouble(in.getString(STOCK_PRICE));
            priceChange = Double.parseDouble(in.getString(STOCK_PRICE_CHANGE));
            percentChange = Double.parseDouble(in.getString(STOCK_PERCENT_CHANGE));

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


}
