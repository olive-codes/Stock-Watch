package com.oliviabecht.stockwatchobechtapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

//implements SwipeRefreshLayout.OnRefreshListener

public class MainActivity extends AppCompatActivity {

    //Rec View to Display Display Stocks
    private RecyclerView recStocks;
    //Array List to hold stocks in
    ArrayList<Stock> allStocks = new ArrayList<>();
    public static final String FILENAME = "stocks.json";
    private SwipeRefreshLayout swipeContainer;
    private Adapter adpNotes;

    //private ArrayList<Stock> existingStocks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //existingStocks = (ArrayList<Stock>) getIntent().getExtras().getSerializable("existingNotes");

        recStocks = findViewById(R.id.recStocks);

        //readStocksFromFile();
        //TODO Sort the symbols alphabetically here
        Collections.sort(allStocks, new Comparator<Stock>() {
            @Override
            public int compare(Stock stock, Stock t1) {
                return stock.getSymbol().compareTo(t1.getSymbol());
            }
        });

        adpNotes = new Adapter(allStocks, getApplicationContext());
        //set the recyclerview to use that adapter
        recStocks.setAdapter(adpNotes);
        //This recycler view DOES NOT KNOW how to show it's items
        //we need to set a layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        //assign the rec view the vertical layout
        recStocks.setLayoutManager(layoutManager);

        //makeSelection();
        NameDownloader.NameDownloaderMethods methods = new NameDownloader.NameDownloaderMethods() {
            @Override
            public void onNamesLoaded() {
                HashMap<String, String> symbolToCompanyName = NameDownloader.symbolToCompanyName;
            }
        };

        NameDownloader.getStockNames(this, methods);

        swipeContainer = (SwipeRefreshLayout) findViewById(R.id.swipeContainer);

        //Menu Button to add stock
        ImageButton addStockButton = (ImageButton) findViewById(R.id.menuButton);
        addStockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Settings.System.getInt(getApplicationContext().getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) == 0){
                    //Yes Network
                    stockSelection();
                } else {
                    //No Network
                    //if there is no network connection aka airplane
                    //error dialog
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("No Network Connection");
                    builder.setMessage("Stocks Cannot Be Updated Without A Network Connection");
                    builder.setCancelable(false);
                    builder.setPositiveButton("OK", (DialogInterface.OnClickListener) (dialog, which) -> {
                        //Stay in main activity
                    });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            }
        });


        //swipe refresh stuff...
        //swipe listener
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                //TODO Update Stocks here!
                swipeContainer.setRefreshing(false);
            }

        });

        //saveStocksToFile();

    }

    //may not need this -> may just want pull down listener
    @Override
    protected void onResume() {
        super.onResume();
    }


    public void stockSelection () {
        //Stock Selection dialog box
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Stock Selection");
        builder.setMessage("Please enter a Stock Symbol:");

        // Set up the input
        final EditText inputStockName = new EditText(this);
        inputStockName.setInputType(InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        builder.setView(inputStockName);
        builder.setCancelable(false);
        builder.setPositiveButton("OK", (DialogInterface.OnClickListener) (dialog, which) -> {

            String input = inputStockName.getText().toString();
            if (allStocks.stream().anyMatch(stock -> stock.getSymbol().equals(input))) {
                //DO NOT ADD STOCK, because it is already added
                //if perfect match and already exsists
                stockExsistsError(input);
            }

            else {
                makeSelection(input);
            }

        });
        builder.setNegativeButton("CANCEL", (DialogInterface.OnClickListener) (dialog, which) -> {
            //Click Cancel - Negative -> do nothing
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void makeSelection (String input) {
        //dialog box
        Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.dlg_stock_results);
        ListView lstResults = dialog.findViewById(R.id.listStockResults);
        ArrayList<String> stocksToShow = new ArrayList<>();
        // filter and get list of keys that contain the input
            Iterator symbolToCompanyNameIterator = NameDownloader.symbolToCompanyName.entrySet().iterator();

            while(symbolToCompanyNameIterator.hasNext()) {
                 Map.Entry<String, String> symbolToCompany = (Map.Entry<String, String>)symbolToCompanyNameIterator.next();
                 if(symbolToCompany.getKey().startsWith(input)) {
                     stocksToShow.add(symbolToCompany.getKey() + "\n " + symbolToCompany.getValue());
                 }
            }

            if (stocksToShow.size() == 0) {
                dialog.dismiss();
                stockNotFoundError(input);
                return;
            }

            if(stocksToShow.size() == 1) {
                String symbolToSend = stocksToShow.get(0).split("\n")[0].trim();
                StockDownloader.getStock(MainActivity.this, symbolToSend, allStocks, dialog, adpNotes);

                saveStocksToFile();

                return;
            }

        ArrayAdapter<String> adpResults = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, stocksToShow);
        lstResults.setAdapter(adpResults);
        lstResults.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Toast.makeText(MainActivity.this, "Fetching info for stock number..." + String.valueOf(position), Toast.LENGTH_SHORT).show();
                String symbolToSend = stocksToShow.get(position).split("\n")[0].trim();
                StockDownloader.getStock(MainActivity.this, symbolToSend, allStocks, dialog, adpNotes);

                saveStocksToFile();

            }
        });
        Button nevermind = dialog.findViewById(R.id.btnNevermind);
        nevermind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void stockExsistsError (String input) {

        Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.error_dialog_stock_exsist);
        TextView errorMessage = dialog.findViewById(R.id.deleteMessage);
        errorMessage.setText("Stock Symbol " + input + " is already displayed");
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
        System.out.println("Error 1");
    }

    public void stockNotFoundError(String input) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Symbol Not Found: " + input);
        builder.setMessage("Data for stock symbol");
        builder.setCancelable(false);
        builder.setPositiveButton("OK", (DialogInterface.OnClickListener) (dialog, which) -> {
            //Stay in main activity
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    /**
     * Save to the notes.json file my new note
     */


    private void saveStocksToFile(){
        try {
            File file = new File(getApplicationContext().getFilesDir(), MainActivity.FILENAME);
            //check to see if this file exists
            String filesDir = getApplicationContext().getFilesDir().getAbsolutePath();
            if (!file.exists()){
                file.createNewFile();
            }
            FileOutputStream fos = openFileOutput(MainActivity.FILENAME, Context.MODE_PRIVATE);

            JSONArray stocksJSONArray = new JSONArray();

            for(Stock s : allStocks) {
                JSONObject newStockObj = new JSONObject();
                newStockObj.put("symbol", s.getSymbol());
                newStockObj.put("company", s.getCompany());
                newStockObj.put("price", s.getPrice());
                newStockObj.put("priceChange", s.getPriceChange());
                newStockObj.put("percentChange", s.getPercentChange());
                stocksJSONArray.put(newStockObj);
            }
            //Log.d("mainActivity", "jsonStr: " + newStockObj);

            fos.write(stocksJSONArray.toString().getBytes());
            fos.close();
        } catch (Exception e) {
            Log.d("Write ERROR", "Error: could not write to note file");
            e.printStackTrace();
        }
        Log.d("Write Success", "good");
    }


/*
    void readStocksFromFile() {
        try {
            File file = new File(getApplicationContext().getFilesDir(), FILENAME);
            // Creating an object of BufferedReader class
            BufferedReader br = new BufferedReader(new FileReader(file));
            String curLine;
            StringBuilder fileContents = new StringBuilder();
            // Condition holds true till
            // there is character in a string
            while ((curLine = br.readLine()) != null) {
                fileContents.append(curLine);
            }

            String jsonFileContents = fileContents.toString();
            //JSONArray object can create an object from a json formatted string
            JSONArray fileJSONArray = new JSONArray(jsonFileContents);
            //go through the json array and for each json object turn it into a note object

            for(int i = 0; i < fileJSONArray.length(); i++) {
                JSONObject curStockObj = fileJSONArray.getJSONObject(i);
                Stock newStock = new Stock(curStockObj);
                allStocks.add(newStock);
            }
        } catch (FileNotFoundException e) {
            //e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            Log.d("DEBUG", "Error: the JSON string in file was incorrect format");
            e.printStackTrace();
        }
    }

 */


}

